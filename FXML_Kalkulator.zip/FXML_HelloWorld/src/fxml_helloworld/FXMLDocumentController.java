/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package fxml_helloworld;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Button;

/**
 *
 * @author indah
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;

    @FXML
    private TextField tf;

    String op="";
    long bilangan1;
    long bilangan2;
    
    @FXML
    private void handleButtonSatu(ActionEvent event){
        tf.setText(tf.getText()+"1");
    }

    @FXML
    private void handleButtonDua(ActionEvent event){
        tf.setText(tf.getText()+"2");
    }

    @FXML
    private void handleButtonTiga(ActionEvent event){
        tf.setText(tf.getText()+"3");
    }

    @FXML
    private void handleButtonEmpat(ActionEvent event){
        tf.setText(tf.getText()+"4");
    }

    @FXML
    private void handleButtonLima(ActionEvent event){
        tf.setText(tf.getText()+"5");
    }

    @FXML
    private void handleButtonEnam(ActionEvent event){
        tf.setText(tf.getText()+"6");
    }

    @FXML
    private void handleButtonTujuh(ActionEvent event){
        tf.setText(tf.getText()+"7");
    }

    @FXML
    private void handleButtonDelapan(ActionEvent event){
        tf.setText(tf.getText()+"8");
    }

    @FXML
    private void handleButtonSembilan(ActionEvent event){
        tf.setText(tf.getText()+"9");
    }

    @FXML
    private void handleButtonNol(ActionEvent event){
        tf.setText(tf.getText()+"0");
    }

    public void Operasi (ActionEvent ae){
        String operasi = ((Button)ae.getSource()).getText();
        if (!operasi.equals("=")){
            if(!op.equals("")){
                return;
            }
            op = operasi;
            bilangan1 = Long.parseLong(tf.getText());
            tf.setText("");
        }else {
            if(op.equals("")){
                return;
            }
            bilangan2 = Long.parseLong(tf.getText());
            hitung(bilangan2, bilangan1, op);
            op="";
        }
    }

    public void hitung (long n1, long n2, String op){
    
        switch (op){
        
            case "+" : tf.setText(n1 + n2 + "");break;
            case "-" : tf.setText(n1 - n2 + "");break;
            case "*" : tf.setText(n1 * n2 + "");break;
            case "/" : 
                if (n2 == 0){
                tf.setText("0");break;
                }
                tf.setText(n1/n2+ "");break;  
        }
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("Its indah calculator");
        label.setText("Its indah calculator");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //TODO
    }    
    
}
