package msproject;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;

import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author indah rahma
 */
public class FXMLTableViewController implements Initializable {
    ObservableList data = observableArrayList(
        new KontakHp("exo", "1984"),
        new KontakHp("eri", "1945"),
        new KontakHp("exol", "1946")
   );

// deklarasi untuk objek di fxml
    @FXML
    private Label label;

    @FXML
    private TextField text1;

    @FXML
    private TextField text2;

    @FXML
    private TextField text3;

    @FXML
    private TextField textField1;

    @FXML
    private TextField textField2;

    @FXML
    private TableColumn tblnama;

    @FXML
    private TableColumn tblkontak;

    @FXML
    private TableView tabel;

    
    @FXML
    private void getHapus(ActionEvent event){
        int text_nomer = Integer.parseInt(text3.getText());
        int x = text_nomer -1;
        data.remove(x);
        text3.setText("");
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        String text_nama = text1.getText();
        String text_kontak = text2.getText();
        data.add(new KontakHp(text_nama, text_kontak));
        text1.setText("");
        text2.setText("");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        tblnama.setCellValueFactory(new PropertyValueFactory<KontakHp, String>("nama"));
        tblkontak.setCellValueFactory(new PropertyValueFactory<KontakHp, String>("kontak"));

        tabel.setItems(data);
    }    
    
}

