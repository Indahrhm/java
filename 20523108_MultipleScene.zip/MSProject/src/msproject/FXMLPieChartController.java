package msproject;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 *
 * @author indahrhm
 */
public class FXMLPieChartController implements Initializable {
    
    ObservableList<PieChart.Data> data =
    FXCollections.observableArrayList();

    @FXML
    private TextField Tx1;

    @FXML
    private TextField Tx2;
    
    @FXML
    private Label label;

    @FXML
    private Button buttondel;

    @FXML
    private Button buttonadd;

    @FXML
    private PieChart pieCht;
    
    @FXML
    private void handleButtondel(ActionEvent event) {
        data.remove(3);
    }
    
    @FXML
    private void handleButtonadd(ActionEvent event) {
        String name = Tx1.getText();
        int value = Integer.parseInt(Tx2.getText());
        PieChart.Data newData = new PieChart.Data(name, value);
        data.add(newData);
        Tx1.clear();
        Tx2.clear();
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        data.add(new PieChart.Data( "Doh Kyungsoo", 50));
        data.add(new PieChart.Data( "Kim Jongin", 40));
        data.add(new PieChart.Data( "Park Chanyeol", 45));
                
        pieCht.setData(data);
    }    
    
}
