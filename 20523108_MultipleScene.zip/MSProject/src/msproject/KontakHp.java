package msproject;

public class KontakHp {
    String nama;
    String kontak;
    
    public KontakHp(String x, String y){
        this.nama = x;
        this.kontak = y;
    }
    
    public String getNama(){
        return nama;
    }
    
    public String getKontak(){
        return kontak;
    }
}
