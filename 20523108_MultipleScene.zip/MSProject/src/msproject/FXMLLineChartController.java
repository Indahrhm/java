package msproject;

    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;

/**
 *
 * @author indahrhm
 */
public class FXMLLineChartController  implements Initializable {
    
    XYChart.Series<String, Integer> Bias = new XYChart.Series<>();
    
    @FXML
    private Label Title;
    
    @FXML
    private LineChart<String, Integer> Laporan;
    
    @FXML
    private Button Add;
    
    @FXML
    private Button Delete;

    @FXML
    private TextField txt1;

    @FXML
    private TextField txt2;
    
    @FXML
    private void handleAdd(ActionEvent event) {
        String xValue = txt1.getText();
        int yValue = Integer.parseInt(txt2.getText());
        Bias.getData().add(new XYChart.Data<>(xValue, yValue));
        txt1.clear();
        txt2.clear();
    }
    
    @FXML
    private void handleDelete(ActionEvent event) {
        if (!Bias.getData().isEmpty()) {
            Bias.getData().remove(Bias.getData().size() - 1);
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        Bias.getData().add(new XYChart.Data<>("Kyungsoo", 30));
        Bias.getData().add(new XYChart.Data<>("Jongin", 40));
               
        Laporan.getData().add(Bias);
    }    
    
}
