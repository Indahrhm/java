package larik;

import com.thoughtworks.xstream.XStream;

public class Hewan {
    private String jenis;
    private int umur;

    public Hewan(String jenis, int umur) {
        this.jenis = jenis;
        this.umur = umur;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }

    public int getUmur() {
        return umur;
    }

    public void setUmur(int umur) {
        this.umur = umur;
    }

    public void suara() {
        System.out.println("Hewan bersuara");
    }

    // Metode untuk mengubah objek menjadi XML
    public String toXML() {
        XStream xstream = new XStream();
        return xstream.toXML(this);
    }
}
