/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package larik;

/**
 *
 * @author indahrhm
 */
public class Larik {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        // double[] myList = new double[10];
        // myList[0] = 1;
        // myList[1] = 2;
        // myList[2] = 3;
        // myList[3] = 4;

        // XStream xstream = new XStream(new StaxDriver());

        // // larik double diubah menjadi string dengan format XML
        // String xml = xstream.toXML(myList);

        // FileOutputStream coba = null;
        // // lengkapi sesuai video tutorial

        // Membuat objek Hewan
        Hewan hewan = new Hewan("Kambing", 5);
        System.out.println("Jenis hewan: " + hewan.getJenis());
        System.out.println("Umur hewan: " + hewan.getUmur());

        // Membuat objek Kucing dan melakukan upcasting ke objek Hewan
        Kucing kucing = new Kucing("Anggora", 1, "Putih");
        Hewan hewanKucing = kucing;
        System.out.println("Jenis hewan kucing: " + hewanKucing.getJenis());
        System.out.println("Umur hewan kucing: " + hewanKucing.getUmur());
        // Memanggil method suara() dari objek Hewan dan Kucing
        hewan.suara();
        hewanKucing.suara();

        // Melakukan downcasting dari objek Hewan ke objek Kucing
        if (hewanKucing instanceof Kucing) {
            Kucing kucing2 = (Kucing) hewanKucing;
            System.out.println("Warna bulu kucing: " + kucing2.getWarnaBulu());
            // Memanggil method suara() dari objek Kucing hasil downcasting
            kucing2.suara();
        }

        // Membuat objek Kucing baru dan menangani exception ketika umurnya tidak valid
        Kucing kucing3 = new Kucing("Persia", -1, "Hitam");
        try {
            if (kucing3.getUmur() < 0) {
                throw new Exception("Umur kucing tidak valid");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        // Mengubah objek menjadi XML
        System.out.println("Objek Hewan dalam bentuk XML: " + hewan.toXML());
        System.out.println("Objek Kucing dalam bentuk XML: " + kucing.toXML());

    }
}
