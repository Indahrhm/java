package larik;

import com.thoughtworks.xstream.XStream;

public class Kucing extends Hewan {
    private String warnaBulu;

    public Kucing(String jenis, int umur, String warnaBulu) {
        super(jenis, umur);
        this.warnaBulu = warnaBulu;
    }

    public String getWarnaBulu() {
        return warnaBulu;
    }

    public void setWarnaBulu(String warnaBulu) {
        this.warnaBulu = warnaBulu;
    }

    @Override
    public void suara() {
        System.out.println("Meong");

    }

    // Metode untuk mengubah objek menjadi XML
    public String toXML() {
        XStream xstream = new XStream();
        return xstream.toXML(this);
    }
}
