package chart;

import javafx.scene.chart.PieChart;

public class Data extends PieChart {
    private String name;
    private int love;

    public Data(String name, int love) {
        this.name = name;
        this.love = love;
    }

    public String getName() {
        return name;
    }

    public int getLove() {
        return love;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLove(int love) {
        this.love = love;
    }
}

    

