/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barchart;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.chart.BarChart; 
import javafx.scene.chart.XYChart;
 
/**
 *
 * @author indahrhm
 */
public class FXMLDocumentController implements Initializable {
    
    XYChart.Series<String, Integer> Bias = new XYChart.Series<>();
    
    @FXML
    private BarChart Laporan;
 
     @FXML
     private Button hapus;
 
     @FXML
     private Label label;
 
     @FXML
     private Button tambah;
 
     @FXML
     private TextField txt1;
 
     @FXML
     private TextField txt2;
    
    @FXML
    private void handleButtonHapus(ActionEvent event) {
        Bias.getData().remove(3);
    }
    
    @FXML
    private void handleButtonTambah(ActionEvent event) {
        String xValue = txt1.getText();
        int yValue = Integer.parseInt(txt2.getText());
        Bias.getData().add(new XYChart.Data<>(xValue, yValue));
        txt1.clear();
        txt2.clear();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Bias.getData().add(new XYChart.Data<>("Jongin", 100));
        Bias.getData().add(new XYChart.Data<>("Kyungsoo", 50));
        Bias.getData().add(new XYChart.Data<>("Baekhyun", 150));
        
        
        Laporan.getData().add(Bias);
    }    
    
}
