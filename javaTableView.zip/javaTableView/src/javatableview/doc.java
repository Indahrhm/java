/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javatableview;

/**
 *
 * @author indah
 */
public class doc {
    
    String Nama;
    String TanggalLahir;
    String Alamat;
    
    public doc(String d, String o, String x){
        this.Nama = d;
        this.TanggalLahir = o;  
        this.Alamat = x;
    }
    
    public String getNama() {
        return Nama;
    }
    
    public String getTanggalLahir() {
        return TanggalLahir;
    }
    
    public String getAlamat() {
        return Alamat;
    }
}
