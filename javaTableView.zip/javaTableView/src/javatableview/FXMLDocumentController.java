/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javatableview;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.collections.ObservableList;
import javafx.scene.control.Button;
import static javafx.collections.FXCollections.observableArrayList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author indah
 */
public class FXMLDocumentController implements Initializable {
    
    ObservableList data = observableArrayList (
        new doc("kyungsoo", "12011968", "seoulIndo"),
        new doc("Indah", "12102001", "seoulIndo")
    );
       
    @FXML
    private Button btn;
    @FXML
    private TextField txtField1;
    @FXML
    private TextField txtField2;
    @FXML
    private TableView tbleVw;
    @FXML
    private TableColumn clm1;
    @FXML
    private TableColumn clm2;
    @FXML
    private TextField txtField3;
    @FXML
    private TableColumn clm3;
    @FXML
    private TextField txtField4;
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
       String Temp1 = txtField1.getText();
       String Temp2 = txtField2.getText();
       String Temp3 = txtField3.getText();
       data.add(new doc(Temp1, Temp2, Temp3));
       txtField1.setText("");
       txtField2.setText("");
       txtField3.setText("");
    }

    @FXML
    private void getHapus(ActionEvent event){
        int text_nomer = Integer.parseInt(txtField4.getText());
        int x = text_nomer -1;
        data.remove(x);
        txtField4.setText("");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        clm1.setCellValueFactory(new PropertyValueFactory<doc, String>("Nama"));
        clm2.setCellValueFactory(new PropertyValueFactory<doc, String>("TanggalLahir"));
        clm3.setCellValueFactory(new PropertyValueFactory<doc, String>("Alamat"));
        tbleVw.setItems(data);
    }    
    
}
